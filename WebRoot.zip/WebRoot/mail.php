<?php
// add your email address here
define("CONTACT_FORM", 'yourname@yourdomain.com');
?>